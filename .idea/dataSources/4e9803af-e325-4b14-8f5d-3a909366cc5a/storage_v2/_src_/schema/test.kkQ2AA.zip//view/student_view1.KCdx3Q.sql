create definer = mysql@`%` view student_view1 as
select `test`.`student`.`name`       AS `name`,
       `test`.`student`.`student_id` AS `student_id`,
       `test`.`student`.`Tid`        AS `Tid`
from `test`.`student`;

