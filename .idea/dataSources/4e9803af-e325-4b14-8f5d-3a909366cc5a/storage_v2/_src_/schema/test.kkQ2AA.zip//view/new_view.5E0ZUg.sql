create definer = mysql@`%` view new_view as
select `test`.`student`.`id` AS `id`, `test`.`student`.`name` AS `name`
from `test`.`student`;

