create definer = mysql@`%` view student_view1_view2 as (select `a`.`name`       AS `name`,
                                                               `a`.`student_id` AS `student_id`,
                                                               `b`.`address`    AS `address`,
                                                               `b`.`age`        AS `age`
                                                        from (`test`.`student_view1` `a`
                                                                 join `test`.`student_view2` `b`
                                                                      on ((`a`.`student_id` = `b`.`student_id`))));

