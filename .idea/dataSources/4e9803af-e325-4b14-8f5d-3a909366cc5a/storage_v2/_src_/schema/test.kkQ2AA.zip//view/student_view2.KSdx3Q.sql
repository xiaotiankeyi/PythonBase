create definer = mysql@`%` view student_view2 as
select `b`.`name` AS `name`, `b`.`student_id` AS `student_id`
from (`test`.`student` `b`
         join (select `test`.`student`.`Tid` AS `Tid`
               from `test`.`student`
               group by `test`.`student`.`Tid`
               having (`test`.`student`.`Tid` <> '')) `a` on ((`b`.`student_id` = `a`.`Tid`)));

